#pragma once

#include <chaos/StandardHeaders.h>


namespace chaos
{

  class SkinnedMesh
  {



  };


}; // namespace chaos
