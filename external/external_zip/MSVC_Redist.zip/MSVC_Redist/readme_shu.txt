This is a raw copy of 
C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Redist\MSVC

necessary while executables requires this runtime DLL (no static link but dynamic (this would be complex due to other library))