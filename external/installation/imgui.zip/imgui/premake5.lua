workspace "ImGUI"
   configurations { "Debug", "Release" }
   
 project "ImGUIOpenGL"
   kind "StaticLib"
   language "C++"
   architecture "x64"
   
   targetdir "bin/%{cfg.buildcfg}"
   
   includedirs {"."}
   files { "*.h", "*.cpp" }
   files { "backends/*glfw*.h", "backends/*glfw*.cpp" }
   files { "backends/*opengl3*.h", "backends/*opengl3*.cpp" }

   includedirs {path.join("..", "glfw-3.3.8", "include")}

   filter "configurations:Debug"
      defines { "DEBUG" }
      symbols "On"

   filter "configurations:Release"
      defines { "NDEBUG" }
      optimize "On"